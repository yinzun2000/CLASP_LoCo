#normalize the 3-D array matrics, p.t provide the quantile
NormalLeg3D <-  function(val.i,p.t=.99)
{

  v.o <-  val.i

  for (i in 1:dim(val.i)[3])
    v.o[,,i]  <-  NormalLeg2D(val.i[,,i],p.t=p.t)

  return(v.o)
}

#normalize the 2-D array matrics, p.t provide the quantile
NormalLeg2D <-  function(val.i,p.t=.99)
{
  pp.t  <-  quantile(abs(val.i),p.t,na.rm=T)

  v.t <-  val.i
  v.t[!is.na(v.t) & v.t > pp.t] <-  pp.t
  v.t[!is.na(v.t) & v.t < -pp.t] <-  -pp.t

  v.o <-  v.t/pp.t

  return(v.o)
}

#quantile the 2-D array matrics, nbd number of quantile band
#between [0,1]
QuaLeg2D <-  function(val.i,nbd=20)
{
  int.t <-  1/nbd
  v.o <-  val.i

  #pp.p  <-  max(abs(val.i),na.rm=T)*1.0001
  pp.p  <-  1e67

  for (i in 1:nbd)
  {
    pp.t  <-  quantile(abs(val.i),probs=1-int.t*i,na.rm=T)
    v.o[!is.na(val.i) & (val.i > pp.t) & (val.i <= pp.p)] <-  1-int.t*i + int.t/2
    v.o[!is.na(val.i) & (val.i < -pp.t) & (val.i >= -pp.p)] <-  -(1-int.t*i + int.t/2)

    pp.p  <-  pp.t
  }

  return(v.o)
}

#calculate a set of quantile and the missing rate
#seq.t a sequence of threshlod
#ab: abs value or not?
Qua2Fit <-  function(v1.i,v2.i,seq.t,ab=T)
{
  qua.o <-  seq.t
  fit.o <-  seq.t
 
  for (i in 1:length(seq.t))
  {
    if (ab)
    {
      qua1  <-  quantile(abs(v1.i),probs=seq.t[i],na.rm=T)
      qua2  <-  quantile(abs(v2.i),probs=seq.t[i],na.rm=T)

      v1.t  <-  v1.i
      v2.t  <-  v2.i

      v1.t[!is.na(v1.t) & abs(v1.t) < qua1] <-  0
      v1.t[!is.na(v1.t) & abs(v1.t) >= qua1] <-  1

      v2.t[!is.na(v2.t) & abs(v2.t) < qua2] <-  0
      v2.t[!is.na(v2.t) & abs(v2.t) >= qua2] <-  1

      kk.t  <-  v1.t*v2.t

      fit.o[i] <-  sum(kk.t,na.rm=T)/length(v1.t[!is.na(v1.t) & abs(v1.t) == 1])

    } else
    {
      qua1  <-  quantile(v1.i,probs=seq.t[i],na.rm=T)
      qua2  <-  quantile(v2.i,probs=seq.t[i],na.rm=T)

      v1.t  <-  v1.i
      v2.t  <-  v2.i

      v1.t[!is.na(v1.t) & v1.t < qua1] <-  0
      v1.t[!is.na(v1.t) & v1.t >= qua1] <-  1

      v2.t[!is.na(v2.t) & v2.t < qua2] <-  0
      v2.t[!is.na(v2.t) & v2.t >= qua2] <-  1

      kk.t  <-  v1.t*v2.t

      fit.o[i] <-  sum(kk.t,na.rm=T)/length(v1.t[!is.na(v1.t) & v1.t == 1])
    }
  }

  v.o <-  list(qua=qua.o,fit=fit.o)
  return(v.o)
}

#create three matrics 
#one with zero, one, two and three
#zero is not significant for both
#one is the significant in v1 but not in v2
#one is the significant in v2 but not in v1
#significant in both v1 and v2
#another two has 0 and 1
GetOneZero  <-  function(v1.i,v2.i,qua.t)
{
  v1.t <-  v1.i
  v2.t <-  v2.i

  qua1  <-  quantile(abs(v1.i),probs=qua.t,na.rm=T)
  qua2  <-  quantile(abs(v2.i),probs=qua.t,na.rm=T)

  v1.t[!is.na(v1.i) & abs(v1.i) < qua1] <-  0
  v1.t[!is.na(v1.i) & abs(v1.i) >= qua1] <-  1

  v2.t[!is.na(v2.i) & abs(v2.i) < qua2] <-  0
  v2.t[!is.na(v2.i) & abs(v2.i) >= qua2] <-  1

  vf.t  <-  v1.t+v2.t*2

  v.o <-  list(m1=v1.t,m2=v2.t,mf=vf.t)

  return(v.o)
}

GetThreeZero  <-  function(v1.i,v2.i,v3.i,qua.t)
{

  v1.t <-  v1.i
  v2.t <-  v2.i
  v3.t <-  v3.i

  qua1  <-  quantile(abs(v1.i),probs=qua.t,na.rm=T)
  qua2  <-  quantile(abs(v2.i),probs=qua.t,na.rm=T)
  qua3  <-  quantile(abs(v3.i),probs=qua.t,na.rm=T)

  v1.t[!is.na(v1.i) & abs(v1.i) < qua1] <-  0
  v1.t[!is.na(v1.i) & abs(v1.i) >= qua1] <-  1

  v2.t[!is.na(v2.i) & abs(v2.i) < qua2] <-  0
  v2.t[!is.na(v2.i) & abs(v2.i) >= qua2] <-  1

  v3.t[!is.na(v3.i) & abs(v3.i) < qua3] <-  0
  v3.t[!is.na(v3.i) & abs(v3.i) >= qua3] <-  1

  vf.t  <-  v1.t+v2.t*2+v3.t*4

  v.o <-  list(m1=v1.t,m2=v2.t,m3=v3.t,mf=vf.t)

  return(v.o)
}

GetIndTrans <-  function(v1.i,v2.i){
    nlon    <-  dim(v1.i)[1]
    nlat    <-  dim(v1.i)[2]

    v.o <-  array(NA,dim=dim(v1.i))

    for (nx in 1:nlon)
    for (ny in 1:nlat)
    {
        if (is.na(v1.i[nx,ny]) | is.na(v2.i[nx,ny]))
            next

        id.x    <-  floor(v1.i[nx,ny]*10) + 1
        id.y    <-  floor(v2.i[nx,ny]*10) + 1

        v.o[nx,ny]  <-  10*(id.y-1) + id.x
    }

    return(v.o)
}

PlotRect    <-  function(exp1,exp2,...){
    kk = array(NA,dim=c(10,10))

    tra.t   <-  seq(1,.5,-.1)

    lons    <-  seq(5,95,10)
    lats    <-  seq(5,95,10)
    image(lons,lats,kk,zlim=c(100,1000),
        xlab='',ylab='',axes=F)
    box()
    axis(2,at=seq(0,100,20),
         labels=seq(1,0,-.2),...)
    axis(3,at=seq(0,100,20),
         labels=seq(0,1,.2),...)
    #mtext(2,text=expression(italic(Q)[M]),line=1.5,
    mtext(2,text=exp1,line=1.5,...)
    mtext(3,text=exp2,line=1.5,...)

    col.rect    <-  NULL

    for (i in 1:10)
    for (j in 1:10)
    {
        v.tmp   <-  kk
        v.tmp[i,11-j]  <-  0

        if (i == j)
        {
            col.v   <-  rgb(1,1,0,0)
        } else if (i < j)
        {
            if (i == 11-j)
            {
                v.t <-  abs(i-j)/12 + .2
                col.v   <-  rgb(0,0,1,v.t)
            } else if (i < 11-j)
            {
                #c.i <-  c(144,15,248)/255
                c.i <-  c(0,0,0)
                c.e <-  c(0,0,1)
                #v.t <-  tra.t[min(i,11-j)]
                v.t <-  abs(i-j)/12 + .2
                c.v <-  c.i*(10-i-j)/(10-3) + c.e*(i+j-3)/(10-3)
                col.v   <-  rgb(c.v[1],c.v[2],c.v[3],v.t)
            } else
            {
                c.i <-  c(0,0,1)
                c.e <-  c(0,1,0)
                #v.t <-  tra.t[min(i,11-j)]
                v.t <-  abs(i-j)/12 + .2
                c.v <-  c.i*(19-i-j)/(19-11) + c.e*(i+j-11)/(19-11)
                col.v   <-  rgb(c.v[1],c.v[2],c.v[3],v.t)
            }
        } else
        {
            if (i == 11-j)
            {
                v.t <-  abs(i-j)/12 + .2
                col.v   <-  rgb(1,0,0,v.t)
            } else if (i < 11-j)
            {
                #c.i <-  c(255,147,150)/255
                c.i <-  c(0,0,0)
                c.e <-  c(1,0,0)
                #v.t <-  tra.t[min(i,11-j)]
                v.t <-  abs(i-j)/12 + .2
                c.v <-  c.i*(10-i-j)/(10-3) + c.e*(i+j-3)/(10-3)
                col.v   <-  rgb(c.v[1],c.v[2],c.v[3],v.t)
            } else
            {
                c.i <-  c(1,0,0)
                c.e <-  c(1,1,0)
                #v.t <-  tra.t[min(i,11-j)]
                v.t <-  abs(i-j)/12  + .2
                c.v <-  c.i*(19-i-j)/(19-11) + c.e*(i+j-11)/(19-11)
                col.v   <-  rgb(c.v[1],c.v[2],c.v[3],v.t)
            }
        }
        image(lons,lats,v.tmp,zlim=c(-1,1),add=T,axes=F,col=col.v)
        col.rect    <-  cbind(col.rect,col.v)
    }
}

GetLines    <-  function(v.m,v.e,v.d,dv.1,rds.1,sdr.1,dsdr.1,
                         dv.2,rds.2,sdr.2,dsdr.2){

    v.o <-  array(0,dim=100)

    q.1 <-  GetQuaL(v.m)
    q.2 <-  GetQuaL(v.e)

    for (nx in 1:dim(v.m)[1])
    for (ny in 1:dim(v.m)[2])
    {
        if (is.na(v.m[nx,ny]) | is.na(v.e[nx,ny]) |
            is.na(v.d[nx,ny]))
            next

        idx <-  10*(q.1[nx,ny] - 1) + q.2[nx,ny]
        v.o[idx]    <-  v.o[idx] + 1
        
    }

    return(v.o)
}

GetQuaThre   <-  function(v.i){
    v.o <-  array(NA,dim=11)

    v.o[1]  <-  min(v.i,na.rm=T)

    for (i in 2:11)
        v.o[i]  <-  quantile(v.i,prob=(i-1)*.1,na.rm=T)

    return(v.o)
}

GetQuaL   <-  function(v.i){
    q.t <-  GetQuaThre(v.i)

    v.o <-  array(NA,dim=dim(v.i))

    for (i in 1:10)
        v.o[!is.na(v.i) & (v.i >= q.t[i]) & (v.i < q.t[i+1])]   <-  i

    return(v.o)
}

GetDom  <-  function(v.1,v.2,rds,sdr,dsdr)
{
    v.s <- v.2-rds
    v.r <- v.2-sdr
    v.sr <- v.2-dsdr

    qq.1    <-  GetQuaVal(v.1)
    qq.2    <-  GetQuaVal(v.2)
    qq.s    <-  GetQuaVal(v.s)
    qq.r    <-  GetQuaVal(v.r)
    qq.sr   <-  GetQuaVal(v.sr)
    

    v.o <-  array(NA,dim=dim(v.1))
    
    for (nx in 1:dim(v.1)[1])
    {
        print(paste0('nx=',nx))
    for (ny in 1:dim(v.1)[2])
    {
        if (is.na(v.1[nx,ny]))# | is.na(v.2[nx,ny]))
            next

        q.1 <-  which.min(abs(qq.1-v.1[nx,ny]))
        q.2 <-  which.min(abs(qq.2-v.2[nx,ny]))
        q.s <-  which.min(abs(qq.s-v.s[nx,ny]))
        q.r <-  which.min(abs(qq.r-v.r[nx,ny]))
        q.sr<-  which.min(abs(qq.sr-v.sr[nx,ny]))

        c.tt    <-  c(q.s-q.1,
                      q.r-q.1,
                      q.sr-q.1)

        if (q.2 >= q.1)
        {
            c.tt[c.tt < 0]  <-  0
            v.o[nx,ny]  <-  which.min(c.tt)
        } else
        {
            c.tt[c.tt > 0]  <-  0
            v.o[nx,ny]  <-  -which.min(abs(c.tt))
        }
    }
    }
    return(v.o)
}

GetBlend    <-  function(v.1,v.2)
{
    v.o <-  array(NA,dim=dim(v.1))

    v.1.t   <-  round(v.1*10,0)
    v.2.t   <-  round(v.2*10,0)

    for (i in 1:dim(v.1)[1])
    for (j in 1:dim(v.1)[2])
    {
        if (is.na(v.1.t[i,j]))
            next

        if (v.1.t[i,j] == 10)
        {
            v.o[i,j] = 1
        } else
            v.o[i,j] = (10-v.1.t[i,j]+1)*(10-v.1.t[i,j])/2 +
                        1 + (10 - v.1.t[i,j] - v.2.t[i,j])
    }
    return(v.o)
}

GetQuaVal   <-  function(v.i,len=100){
    v.o <-  array(NA,dim=len+1)

    thr.t   <-  seq(0,1,length.out=len)

    for (i in 1:(len+1))
        v.o[i]  <-  quantile(v.i,probs=thr.t[i],na.rm=T)

    return(v.o)
}
