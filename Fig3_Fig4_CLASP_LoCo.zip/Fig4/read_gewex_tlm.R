library(ncdf4)


filei <-  'msk_era5_gewex.nc'
nci <-  nc_open(filei)
msk <-  ncvar_get(nci,'lsm')
nc_close(nci)

filei <-  'TLM_globe.nc'

nci <-  nc_open(filei)
lons  <-  ncvar_get(nci,'lon')
lats  <-  ncvar_get(nci,'lat')
lfc.d <-  ncvar_get(nci,'lfc_d')
lfc.e <-  ncvar_get(nci,'lfc_e')
lfc.m <-  ncvar_get(nci,'lfc_m')
fac.d <-  ncvar_get(nci,'fac_d')
fac.e <-  ncvar_get(nci,'fac_e')
fac.m <-  ncvar_get(nci,'fac_m')
lac.d <-  ncvar_get(nci,'lac_d')
lac.e <-  ncvar_get(nci,'lac_e')
lac.m <-  ncvar_get(nci,'lac_m')
nc_close(nci)


lfc.d[msk < .5] <- NA 
lfc.e[msk < .5] <- NA 
lfc.m[msk < .5] <- NA 
fac.d[msk < .5] <- NA 
fac.e[msk < .5] <- NA 
fac.m[msk < .5] <- NA 
lac.d[msk < .5] <- NA 
lac.e[msk < .5] <- NA 
lac.m[msk < .5] <- NA 
