source('lib_plot.R')
source('lib.R')
library("png")
library("eulerr")

#Here we calculate the contribution of rho and segma in the pattern change

if (!exists('lfc.d'))
{
  source('read/gewex/read_gewex_tlm.R')
  col.rect  <-  as.matrix(read.table('col.rect'))
}

bg.p  <-  c(.05,.85,.05,.95)
sm.p  <-  c(.87,.9,.05,.85)

lab.sea <-  c('MAM','JJA','SON','DJF')
lab.s <-  c('(a)','(b)','(c)','(d)')

max.t <-  1
ra.t  <-  c(-max.t,max.t)
br.t  <-  seq(-max.t,max.t,.1)
n.col <-  length(br.t) - 1
qua.th  <-  .85

fileo <-  paste0('fac_venn_jja_gewex.pdf')
pdf(fileo,height=3.5,width=8)
par(oma=rep(0,4),
    mar=c(.1,.1,.1,.1))

v.d <-  fac.d
v.e <-  fac.e
v.m <-  fac.m

fac.d.u <-  QuaLeg2D(abs(v.d),nbd=10)
fac.e.u <-  QuaLeg2D(abs(v.e),nbd=10)
fac.m.u <-  QuaLeg2D(abs(v.m),nbd=10)

val.t <-  GetThreeZero(v.m,v.e,
                       v.d,qua.th)
image(lons,lats,val.t$mf,zlim=c(.5,7.5),
      breaks=seq(.5,7.5,1),col=col.venn,
      axes=F)
box()
plot(coastsCoarse,add=T)
venn.img = readPNG(paste0('venn_gewex.png'))
rasterImage(venn.img,-170,-50,-120,0)
cex.tt  <-  1.5
text(-164.5,-33,'M',cex=cex.tt)
text(-128,-40,'E',cex=cex.tt)
text(-137,-8,'D',cex=cex.tt)

dev.off()
