library(RColorBrewer)
library(rworldmap)
library(fields)
library(mapdata)
library(khroma)

col.set <-  colorRampPalette(brewer.pal(12,'Set3'))
col.set1 <-  colorRampPalette(brewer.pal(9,'Set1'))
col.pair <-  colorRampPalette(brewer.pal(12,'Paired'))
col.yob <-  colorRampPalette(brewer.pal(9,'YlOrRd'))
col.gb  <-  colorRampPalette(brewer.pal(9,'GnBu'))

col.comb  <-  c(4,5,10)

col.r <-  rgb(1,0,0,.3)
col.g <-  rgb(0,1,0,.3)
col.b <-  rgb(0,0,1,.3)

#belongs to the library khroma
col.broc <- colour("broc")
col.cork <- colour("cork")
col.vik <- colour("vik")
col.lisbon <- colour("lisbon")
col.tofino <- colour("tofino")
col.berlin <- colour("berlin")
col.roma <- colour("roma",force=T,reverse=T)
col.bam <- colour("bam")
col.vanimo <- colour("vanimo")
col.batlow <- colour("batlow")
col.batlowW <- colour("batlowW")
col.batlowK <- colour("batlowK")
col.devon <- colour("devon")
col.lajolla <- colour("lajolla")
col.bamako <- colour("bamako")
col.davos <- colour("davos")
col.bilbao <- colour("bilbao")
col.nuuk <- colour("nuuk")
col.oslo <- colour("oslo")
col.grayC <- colour("grayC")
col.hawaii <- colour("hawaii")
col.lapaz <- colour("lapaz")
col.tokyo <- colour("tokyo")
col.buda <- colour("buda")
col.acton <- colour("acton")
col.turku <- colour("turku")
col.imola <- colour("imola")
col.oleron <- colour("oleron")
col.bukavu <- colour("bukavu")
col.fes <- colour("fes")

col.venn    <-  c(rgb(.23,.60,.66), rgb(.95,.49,.56), rgb(.71,.73,.82), rgb(.96,.62,.21), rgb(.74,.82,.56),rgb(.97,.75,.5),rgb(.81,.68,.55))


GetColPat   <-  function(v.min,v.max,n.seg=50){
    if (v.min > 0)
    {
        col.p   <-  col.yob(n.seg - 1)
        col.tfs <-  c('white',col.p)
        br.t    <-  c(0,seq(v.min,v.max,
                            length.out=n.seg))
    } else
    {
        l.n <-  -v.min
        l.p <-  v.max
        len.n   <-  round(n.seg*l.n/(l.n+l.p),0)
        len.p   <-  round(n.seg*l.p/(l.n+l.p),0)

        if (len.n < 2)
        {
            col.n   <-  rev(col.gb(10))[8]
            col.p   <-  col.yob(n.seg - 2)
            col.tfs <-  c(col.n,rep('white',2),
                          col.p)
            br.t    <-  c(seq(v.min,0,
                              length.out=3),
                          seq(0,v.max,
                              length.out=n.seg))
            br.t    <-  unique(br.t)
        } else
        {
            col.n   <-  rev(col.gb(len.n - 1))
            col.p   <-  col.yob(len.p - 1)
            col.tfs <-  c(col.n,rep('white',2),
                          col.p)
            br.t    <-  c(seq(v.min,0,
                              length.out=len.n+1),
                          seq(0,v.max,
                              length.out=len.p+1))
            br.t    <-  unique(br.t)
        }

    }

    return(list(col=col.tfs,br=br.t))
}

GetColPat2   <-  function(v.min,v.max,n.seg=50){
    if (v.min > 0)
    {
        #col.p   <-  col.yob(n.seg - 1)
        col.p   <-  tim.colors(2*(n.seg - 1))[n.seg:(2*n.seg-2)]
        col.tfs <-  c('white',col.p)
        br.t    <-  c(0,seq(v.min,v.max,
                            length.out=n.seg))
    } else
    {
        l.n <-  -v.min
        l.p <-  v.max
        len.n   <-  round(n.seg*l.n/(l.n+l.p),0)
        len.p   <-  round(n.seg*l.p/(l.n+l.p),0)

        if (len.n < 2)
        {
            col.n   <-  tim.colors(50)[10]
            col.p   <-  tim.colors(2*(n.seg - 2))[(n.seg-1):(2*n.seg-4)]
            col.tfs <-  c(col.n,rep('white',2),
                          col.p)
            br.t    <-  c(seq(v.min,0,
                              length.out=3),
                          seq(0,v.max,
                              length.out=n.seg))
            br.t    <-  unique(br.t)
        } else
        {
            col.n   <-  col.davos(len.n - 1)
            col.p   <-  tim.colors(2*(len.p - 1))[len.p:(2*len.p-2)]
            col.tfs <-  c(col.n,rep('white',2),
                          col.p)
            br.t    <-  c(seq(v.min,0,
                              length.out=len.n+1),
                          seq(0,v.max,
                              length.out=len.p+1))
            br.t    <-  unique(br.t)
        }

    }

    return(list(col=col.tfs,br=br.t))
}
