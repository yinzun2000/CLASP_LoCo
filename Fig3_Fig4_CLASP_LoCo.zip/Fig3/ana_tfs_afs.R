#This is the script to calculate TFS from ERA5 reanalysis Assumping that you
#have morning flux (flx), and afternoon precip (pre) for each time zone and
#for summer (JJA and DJF for the north and south hemisphere, respectively).
library(ncdf4)
source('lib_LoCo.R')

n.yr  <-  30

#read the mask
filei <-  '/path_to_landmask/msk_land_era5.nc'
nci <-  nc_open(filei)
lons.msk <-  ncvar_get(nci,'longitude')
lats.msk <-  ncvar_get(nci,'latitude')
msk <-  ncvar_get(nci,'lsm')
nc_close(nci)

path.i  <-  '/path_to_data/'
izone <-  commandArgs(trailingOnly = TRUE)

#read data: flx, covert from [J.m-2] to [W.m-2]
nci <-  nc_open(paste0(path.i,'flx/flx_sou_',izone,'_jja_am.nc'))
lons  <-  ncvar_get(nci,'longitude')
lats.s  <-  ncvar_get(nci,'latitude')
shf.s <-  -ncvar_get(nci,'sshf')/3600
lhf.s <-  -ncvar_get(nci,'slhf')/3600
nc_close(nci)
nci <-  nc_open(paste0(path.i,'flx/flx_nor_',izone,'_jja_am.nc'))
lats.n  <-  ncvar_get(nci,'latitude')
shf.n <-  -ncvar_get(nci,'sshf')/3600
lhf.n <-  -ncvar_get(nci,'slhf')/3600
nc_close(nci)

#read data: precipitation, convert from [m.hr-1] to [mm.6hr-1]
nci <-  nc_open(paste0(path.i,'pre/pre_sou_',izone,'_jja_am.nc'))
pre.s.am <-  ncvar_get(nci,'tp')*6e3
nc_close(nci)
nci <-  nc_open(paste0(path.i,'pre/pre_nor_',izone,'_jja_am.nc'))
pre.n.am <-  ncvar_get(nci,'tp')*6e3
nc_close(nci)
nci <-  nc_open(paste0(path.i,'pre/pre_sou_',izone,'_jja_pm.nc'))
pre.s.pm <-  ncvar_get(nci,'tp')*6e3
nc_close(nci)
nci <-  nc_open(paste0(path.i,'pre/pre_nor_',izone,'_jja_pm.nc'))
pre.n.pm <-  ncvar_get(nci,'tp')*6e3
nc_close(nci)

if (izone != 24)
{
    n.lon <-  length(lons)
} else
    n.lon <-  length(lons) - 1
n.lat.s <-  length(lats.s)
n.lat.n <-  length(lats.n)
n.lat <-  n.lat.s+n.lat.n-1
n.t.s <-  dim(pre.s.pm)[3]
n.t.n <-  dim(pre.n.pm)[3]

#get the land mask for south and north
msk.s <-  msk[which.min(abs(lons.msk - lons[1])):
              which.min(abs(lons.msk - lons[n.lon])),
              which.min(abs(lats.msk - lats.s[1])):
              which.min(abs(lats.msk - lats.s[n.lat.s]))]
msk.n <-  msk[which.min(abs(lons.msk - lons[1])):
              which.min(abs(lons.msk - lons[n.lon])),
              which.min(abs(lats.msk - lats.n[1])):
              which.min(abs(lats.msk - lats.n[n.lat.n]))]

ef.s  <-  lhf.s/(shf.s+lhf.s)
ef.n  <-  lhf.n/(shf.n+lhf.n)

tfs.o <-  array(NA,dim=c(n.lon,n.lat))
ef.o  <-  array(NA,dim=c(n.lon,n.lat))
afs.o <-  array(NA,dim=c(n.lon,n.lat))

for (nx in 1:n.lon)
{
    print(paste0('x1=',nx))
for (ny in 1:(n.lat.s-1))
{
    if (msk.s[nx,ny] < .5)
        next

    tfs.tmp <-  CalTFSAFS(ef.s[nx,ny,],pre.s.am[nx,ny,],
                          pre.s.pm[nx,ny,],pre.thr=1)
    tfs.o[nx,ny]  <-  tfs.tmp$tfs
    ef.o[nx,ny]   <-  tfs.tmp$ef
    afs.o[nx,ny]  <-  tfs.tmp$afs
}
}

for (nx in 1:n.lon)
{
    print(paste0('x2=',nx))
for (ny in 1:n.lat.n)
{
    if (msk.n[nx,ny] < .5)
        next

tfs.tmp <-  CalTFSAFS(ef.n[nx,ny,],pre.n.am[nx,ny,],
                      pre.n.pm[nx,ny,],pre.thr=1)
    tfs.o[nx,n.lat.s-1+ny]  <-  tfs.tmp$tfs
    ef.o[nx,n.lat.s-1+ny]   <-  tfs.tmp$ef
    afs.o[nx,n.lat.s-1+ny]  <-  tfs.tmp$afs
}
}

##write the result out into NetCDF
lons.o  <-  lons
lats.o  <-  c(lats.s[1:(n.lat.s-1)],lats.n)

fileo <-  paste0('dat/TFS_',izone,'.nc')
x.dim <-  ncdim_def("lon","longitude",lons.o[1:n.lon])
y.dim <-  ncdim_def("lat","latitude",lats.o)

tfs.v <-  ncvar_def("TFS","mm",list(x.dim,y.dim),
                    NA,"triggering feedback strength")
ef.v  <-  ncvar_def("s_ef","mm",list(x.dim,y.dim),
                    NA,"standard deviation of EF")
afs.v <-  ncvar_def("AFS","mm",list(x.dim,y.dim),
                    NA,"amplification feedback strength")

nco <-  nc_create(fileo,list(tfs.v,ef.v,afs.v))

ncvar_put(nco,tfs.v,tfs.o)
ncvar_put(nco,ef.v,ef.o)
ncvar_put(nco,afs.v,afs.o)

nc_close(nco)
