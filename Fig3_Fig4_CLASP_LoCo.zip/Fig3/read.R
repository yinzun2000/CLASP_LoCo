library(ncdf4)
library(fields)
source('lib_plot.R')

nci <-  nc_open('TFS_3bin_seg_30yr.nc')
lons    <-  ncvar_get(nci,'lon')
lats    <-  ncvar_get(nci,'lat')
tfs.3.seg.30    <-  ncvar_get(nci,'TFS')
tfs.sd    <-  ncvar_get(nci,'s_ef')
nc_close(nci)

lon.w   <-  which.min(abs(lons + 126))
lon.e   <-  which.min(abs(lons + 66))
lat.n   <-  which.min(abs(lats - 50))
lat.s   <-  which.min(abs(lats - 20))

lon.us  <-  seq(lon.w,lon.e)
lat.us  <-  seq(lat.s,lat.n)
