#here we read the data and plot three figures showing the TFS and the two components of TFS.

source('lib_plot.R')

if (!exists('tfs.3.seg.30'))
    source('read.R')

tfs.min <-  -.005
tfs.max <-  0.238
kk  <-  GetColPat2(tfs.min,tfs.max)

pdf('tfs_conus.pdf',width=10,height=10)
par(mar=c(2,1,.5,.5),oma=rep(.2,4),
    cex=1.2)
plot(1,1,type='n',xlab='',ylab='',axes=F)

par(new=T,fig=c(0.02,.85,.48,.98),mar=rep(0,4))
tfs.t   <-  tfs.3.seg.30[lon.us,lat.us]
tfs.o   <-  tfs.t
tfs.o[tfs.o < tfs.min]  <-  tfs.min
tfs.o[tfs.o > tfs.max]  <-  tfs.max
image(lons[lon.us],lats[lat.us],
           tfs.o, xlab='',ylab='',
           zlim=c(tfs.min,tfs.max),
           axes=F,
           breaks=kk$br,col=kk$col)
box()
plot(coastsCoarse,add=T)
text(-125.2,21.5,pos=4,labels='(a)',cex=1.7)

par(new=T,fig=c(0.84,.92,.5,.92),mar=rep(0,4))
image.plot(tfs.o,legend.only=T,
           smallplot=c(.3,.8,0,1),
           zlim=c(tfs.min,tfs.max),
           axis.args=list(cex.axis=1.2,
                          mgp=c(3,.8,0)),
           legend.args=list(text='        TFS [-]',
                            cex=1.5,
                            line=.5,
                            side=3),
           breaks=kk$br,col=kk$col)

par(new=T,fig=c(0.02,.49,.15,.45),mar=rep(0,4))
s.o <-  (tfs.3.seg.30/tfs.sd)[lon.us,lat.us]
v.min <-  quantile(s.o,probs=.01,
                     na.rm=T)
v.max <-  quantile(s.o,probs=.99,
                     na.rm=T)
kk  <-  GetColPat2(v.min,v.max,100)
s.o[s.o < v.min]  <-  v.min
s.o[s.o > v.max]  <-  v.max
image(lons[lon.us],lats[lat.us],
           s.o, xlab='',ylab='',
           zlim=c(v.min,v.max),
           breaks=kk$br,col=kk$col,
           axes=F)
box()
plot(coastsCoarse,add=T)
text(-125.2,22,pos=4,labels='(b)',cex=1.9)
par(new=T,fig=c(0.02,.49,0,.15),mar=rep(0,4))
image.plot(s.o,legend.only=T,
           zlim=c(v.min,v.max),
           horizontal=T,
           smallplot=c(0.05,.95,.6,.9),
           axis.args=list(cex.axis=1.5),
           legend.args=list(text=
                    expression(partialdiff*Gamma*'[r]'/
                               partialdiff*EF*' [-]'),
                    cex=1.7,
                    line=3,
                    side=1),
           breaks=kk$br,col=kk$col)

par(new=T,fig=c(0.51,.98,.15,.45),mar=rep(0,4))
s.o <-  tfs.sd[lon.us,lat.us]
v.min <-  quantile(s.o,probs=.01,
                     na.rm=T)
v.max <-  quantile(s.o,probs=.99,
                     na.rm=T)
kk  <-  GetColPat2(v.min,v.max,100)
s.o[s.o < v.min]  <-  v.min
s.o[s.o > v.max]  <-  v.max
image(lons[lon.us],lats[lat.us],
           s.o, xlab='',ylab='',
           zlim=c(v.min,v.max),
           breaks=kk$br,col=kk$col,
           axes=F)
box()
plot(coastsCoarse,add=T)
text(-125.2,22,pos=4,labels='(c)',cex=1.9)
par(new=T,fig=c(0.51,.98,0,.15),mar=rep(0,4))
image.plot(s.o,legend.only=T,
           zlim=c(v.min,v.max),
           horizontal=T,
           smallplot=c(0.05,.95,.6,.9),
           axis.args=list(cex.axis=1.5),
           legend.args=list(text=
                    expression(sigma['EF']*' [-]'),
                    cex=1.7,
                    line=3,
                    side=1),
           breaks=kk$br,col=kk$col)
dev.off()

